# ACME Baristas Market Expansion Analysis

## Project Overview

This project analyzes population, country, and coffee market datasets to identify the top three markets for ACME Baristas expansion.

## Tools Used

* Python(Pandas)
* PostgreSQL
* SQL
* Plotly
* Jupyter Notebook (Platform)

## Project Structure(WorkFlow)

python: Data cleaning, wrangling and analysis scripts
sql: SQL transformation and analysis scripts
outputs: Exported analysis outputs
db: PostgreSQL database dump
notebook: Analysis notebook and visualizations

## How to Run the Pipeline

Step1

Run the Python data cleaning script to prepare.

fact_population
dim_country
dim_coffee

Step2

Load the cleaned tables into PostgreSQL.

Step3

Execute the SQL script files:

01_data_quality_checks.sql
02_population_trend_analysis.sql
03_market_growth_analysis.sql
04_coffee_event_analysis.sql

Step4

Open the notebook to review visualizations and business insights.

# Reflection Questions

## Key Design Choices

I adopted a dimensional model consisting of one fact table (fact_population) and two dimension tables (dim_country and dim_coffee).
Python was used for data wrangling, while PostgreSQL and SQL were used for analysis.

## Challenges Faced

The biggest challenge was reshaping the population dataset and validating country mappings using ISO3 codes.

## Assumptions

Population size and growth were used as indicators of market potential.

## What Would I Do Differently?

With additional time, I would incorporate GDP, coffee consumption statistics, and competitive landscape data to improve market selection accuracy.

## Additional Data That Would Strengthen Insights

* Coffee consumption by country
* GDP per capita
* Urban population
* Competitor presence
* Consumer spending behavior

## Conclusion

This analysis helps ACME Baristas find good markets for expansion using population and market data. 
It supports decision-making on where to open new stores globally.